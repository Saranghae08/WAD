
var.box=document.getElementById("display");

function display.value+'()
{
	box.value +=x;

	if (x=="C")
	{
		box.value='';
	}
}

function answer()
{
	 x=box.value;
	 x=eval(x);
	 box.value=x
}